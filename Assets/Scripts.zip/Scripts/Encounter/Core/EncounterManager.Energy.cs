using UnityEngine;
using System;

public partial class EncounterManager
{
    [Header("Energy (Regen)")]
    [Tooltip("If SaveManager.Data has encounterMax/Cost, those win; otherwise these are used.")]
    [SerializeField, Min(1)] private int fallbackEncounterMax = 10;
    [SerializeField, Min(1)] private int fallbackEncounterCost = 1;
    [Tooltip("Seconds required to regenerate 1 energy point.")]
    [SerializeField, Min(1f)] private float energySecondsPerPoint = 3600f;

    // PlayerPrefs ONLY for regen timing (NOT points)
    const string PP_ENERGY_LAST = "ENERGY_lastUnix";
    const string PP_ENERGY_REM  = "ENERGY_remainder";

    long  _energyLastUnix;
    float _energyRemainderSecs;
    float _tickAccum;

    // ─────────────────────────────────────────────────────────────
    // Public API
    // ─────────────────────────────────────────────────────────────

    public int GetEnergyPoints() => GetBankEnergy();

    public int GetEncounterMax() =>
        (SaveManager.Data != null && SaveManager.Data.encounterMax > 0)
            ? SaveManager.Data.encounterMax
            : fallbackEncounterMax;

    public int GetEncounterCost() =>
        (SaveManager.Data != null && SaveManager.Data.encounterCost > 0)
            ? SaveManager.Data.encounterCost
            : fallbackEncounterCost;

    public bool HasEnergy() => GetEnergyPoints() >= GetEncounterCost();

    public int GetSecondsUntilFull()
    {
        int max = GetEncounterMax();
        int cur = GetEnergyPoints();
        if (cur >= max) return 0;

        int missing = max - cur;
        double total = (missing * energySecondsPerPoint) - _energyRemainderSecs;
        return Mathf.Max(0, (int)Math.Ceiling(total));
    }

    public void AddEnergy(int amount, bool allowOvercap = true)
    {
        if (amount == 0) return;

        int max    = GetEncounterMax();
        int before = GetBankEnergy();

        int next = before + amount;

        if (!allowOvercap)
            next = Mathf.Min(next, max);

        next = Mathf.Max(0, next);

        SetBankEnergy(next);
        ClampEnergyBank();

        int after  = GetBankEnergy();
        int gained = Mathf.Max(0, after - before);

        // When energy increases, update last-tick time so regen math stays sane
        _energyLastUnix = NowUnix();

        SaveEnergyTimers();
        MirrorEnergyIntoSaveData(); // optional legacy mirror
        GameEvents.EnergyChanged?.Invoke();
        OnStateChanged?.Invoke();

        if (gained > 0)
            OnEnergyGained?.Invoke(gained, after);
    }

    public bool SpendEnergy()
    {
        int cost = GetEncounterCost();
        int cur  = GetBankEnergy();
        if (cur < cost) return false;

        int next = cur - cost;
        if (next < 0) next = 0;

        SetBankEnergy(next);
        ClampEnergyBank();

        // Reset timing baseline on spend
        _energyLastUnix = NowUnix();
        _energyRemainderSecs = 0f;

        SaveEnergyTimers();
        MirrorEnergyIntoSaveData(); // optional legacy mirror
        GameEvents.EnergyChanged?.Invoke();
        OnStateChanged?.Invoke();
        return true;
    }

    public bool SpendEnergyIfPossible() => SpendEnergy();

    // ─────────────────────────────────────────────────────────────
    // Lifecycle hooks expected by the main EncounterManager
    // (Call these from EncounterManager.Awake/Start/Update as you do now)
    // ─────────────────────────────────────────────────────────────

    void LoadEnergy()
    {
        // Ensure bank exists
        ResourceBank.EnsureSize();

        // If bank energy is uninitialized for a brand new save, default to FULL.
        // This prevents "0 energy on first boot" if nothing set it yet.
        int max = GetEncounterMax();
        int cur = GetBankEnergy();
        if (cur <= 0 && max > 0)
        {
            SetBankEnergy(max);
        }

        // Load regen timers
        string lastStr = PlayerPrefs.GetString(PP_ENERGY_LAST, NowUnix().ToString());
        long parsed;
        _energyLastUnix = long.TryParse(lastStr, out parsed) ? parsed : NowUnix();
        _energyRemainderSecs = PlayerPrefs.GetFloat(PP_ENERGY_REM, 0f);

        ClampEnergyBank();

        _energyRemainderSecs = Mathf.Clamp(
            _energyRemainderSecs,
            0f,
            Mathf.Max(0f, energySecondsPerPoint - 0.001f)
        );

        MirrorEnergyIntoSaveData(); // optional legacy mirror
    }

    void ApplyOfflineRegen()
    {
        int max = GetEncounterMax();
        int cur = GetBankEnergy();

        if (cur >= max)
        {
            _energyRemainderSecs = 0f;
            SaveEnergyTimers();
            return;
        }

        long elapsed = NowUnix() - _energyLastUnix;
        if (elapsed <= 0) return;

        double total = _energyRemainderSecs + elapsed;
        int gained = (int)Math.Floor(total / energySecondsPerPoint);
        _energyRemainderSecs = (float)(total - (gained * energySecondsPerPoint));

        if (gained > 0)
        {
            int next = Mathf.Min(max, cur + gained);
            SetBankEnergy(next);

            if (next >= max) _energyRemainderSecs = 0f;

            MirrorEnergyIntoSaveData(); // optional legacy mirror
            SaveEnergyTimers();
            GameEvents.EnergyChanged?.Invoke();

            OnEnergyGained?.Invoke(gained, next);
        }

        _energyLastUnix = NowUnix();
        SaveEnergyTimers();
    }

    void TickEnergyRuntime()
    {
        int max = GetEncounterMax();
        int cur = GetBankEnergy();
        if (cur >= max) return;

        _tickAccum += Time.unscaledDeltaTime;
        if (_tickAccum < 1f) return;
        _tickAccum = 0f;

        _energyRemainderSecs += 1f;
        if (_energyRemainderSecs >= energySecondsPerPoint)
        {
            _energyRemainderSecs -= energySecondsPerPoint;

            int before = cur;
            int next = Mathf.Min(max, before + 1);
            SetBankEnergy(next);

            if (next >= max) _energyRemainderSecs = 0f;

            MirrorEnergyIntoSaveData(); // optional legacy mirror
            SaveEnergyTimers();
            GameEvents.EnergyChanged?.Invoke();
            OnStateChanged?.Invoke();

            int gained = Mathf.Max(0, next - before);
            if (gained > 0)
                OnEnergyGained?.Invoke(gained, next);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Internal helpers
    // ─────────────────────────────────────────────────────────────

    int GetBankEnergy()
    {
        ResourceBank.EnsureSize();
        return ResourceBank.Get(ResourceType.Energy);
    }

    void SetBankEnergy(int value)
    {
        ResourceBank.EnsureSize();
        ResourceBank.Set(ResourceType.Energy, Mathf.Max(0, value));
        // ResourceBank.Set emits Save + OnResourcesChanged already.
    }

    void ClampEnergyBank()
    {
        int max = GetEncounterMax();
        int cur = GetBankEnergy();
        int clamped = Mathf.Clamp(cur, 0, Mathf.Max(1, max));
        if (clamped != cur)
            SetBankEnergy(clamped);
    }

    void SaveEnergyTimers()
    {
        PlayerPrefs.SetString(PP_ENERGY_LAST, _energyLastUnix.ToString());
        PlayerPrefs.SetFloat(PP_ENERGY_REM, _energyRemainderSecs);
        PlayerPrefs.Save();
    }

    void MirrorEnergyIntoSaveData()
    {
        // Optional: keep legacy field synced so old UI/debug systems still show the right number.
        // IMPORTANT: This is NOT authoritative; ResourceBank is.
        if (SaveManager.Data == null) return;

        int bank = GetBankEnergy();
        if (SaveManager.Data.encounterPoints != bank)
        {
            SaveManager.Data.encounterPoints = bank;
            SaveManager.Save();
        }
    }

    static long NowUnix() => DateTimeOffset.UtcNow.ToUnixTimeSeconds();
}
