using System;
using UnityEngine;
using System.Collections.Generic;

public static class XPManager
{
    private static OwnedMonsterData FindCanonicalInSave(OwnedMonsterData source)
    {
        var data = SaveManager.Data;
        if (data == null || source == null) return null;

        // 1) Prefer OWNED LIST by ownedUID
        if (!string.IsNullOrEmpty(source.ownedUID) && data.owned != null)
        {
            var match = data.owned.Find(o => o != null && o.ownedUID == source.ownedUID);
            if (match != null) return match;
        }

        // 2) Then OWNED LIST by monsterId (fallback)
        if (!string.IsNullOrEmpty(source.monsterId) && data.owned != null)
        {
            var match = data.owned.Find(o => o != null && o.monsterId == source.monsterId);
            if (match != null) return match;
        }

        // 3) Only fall back to TEAM if we truly can't find it in owned

        // Team by ownedUID
        if (!string.IsNullOrEmpty(source.ownedUID) && data.team != null)
        {
            var match = data.team.Find(o => o != null && o.ownedUID == source.ownedUID);
            if (match != null) return match;
        }

        // Team by monsterId
        if (!string.IsNullOrEmpty(source.monsterId) && data.team != null)
        {
            var match = data.team.Find(o => o != null && o.monsterId == source.monsterId);
            if (match != null) return match;
        }

        return null;
    }

    /// <summary>
    /// Public resolver: returns the canonical OwnedMonsterData from SaveManager.Data
    /// that matches this one by ownedUID or monsterId; if none found, falls back
    /// to the original reference.
    /// </summary>
    public static OwnedMonsterData Resolve(OwnedMonsterData source)
    {
        if (source == null) return null;
        var canonical = FindCanonicalInSave(source);
        return canonical ?? source;
    }

    /// <summary>
    /// Perform a single manual level-up:
    /// - Spend Growth Cores
    /// - Increment level
    /// - Add unspent stat points
    /// - Clamp HP to new max
    /// - Save + fire OnTeamChanged
    /// Returns true if level-up succeeded.
    /// </summary>
    public static bool TryManualLevelUp(
        OwnedMonsterData raw,
        int pointsPerLevel,
        LevelCostCurveSO levelCostCurve,
        MonsterLibrarySO monsterLibrary = null)
    {
        if (raw == null || levelCostCurve == null)
            return false;

        // Canonical target is whatever actually lives inside SaveManager.Data
        var target = FindCanonicalInSave(raw) ?? raw;
        if (target == null || string.IsNullOrEmpty(target.monsterId))
            return false;

        var rm = ResourceManager.I;
        if (rm == null) return false;

        // Cost for NEXT level based on current level in save
        int need = levelCostCurve.CoresToNextLevel(target.level);
        int have = rm.Get(ResourceType.GrowthCore);
        if (have < need || need <= 0)
            return false;

        // Spend cores
        rm.Add(ResourceType.GrowthCore, -need);

        // Level up + stat points (on canonical)
        target.level = Mathf.Max(1, target.level + 1);
        target.unspentStatPoints += Mathf.Max(0, pointsPerLevel);

        // Normalize shiny identity (defensive)
        NormalizeShinyFields(target);

        // Clamp HP to new max
        MonsterDataSO def = null;
        if (monsterLibrary != null)
            def = monsterLibrary.GetById(target.monsterId);
        else
            def = MonsterLibraryLocator.GetById(target.monsterId);

        if (def)
        {
            int basePlusLevel = Mathf.RoundToInt(BattleCalc.CalcHP(def, target.level));
            int totalMaxHP = basePlusLevel + Mathf.Max(0, target.trainingBonus.hp);

            if (target.currentHP > totalMaxHP)
                target.currentHP = totalMaxHP;
        }

        // Ensure this canonical monster exists in Data.owned and uses THIS reference (or merges correctly)
        var data = SaveManager.Data;
        if (data != null)
        {
            data.owned ??= new List<OwnedMonsterData>();

            OwnedMonsterData ownedMatch = null;

            // Try match by ownedUID
            if (!string.IsNullOrEmpty(target.ownedUID))
                ownedMatch = data.owned.Find(o => o != null && o.ownedUID == target.ownedUID);

            // Fallback: match by monsterId
            if (ownedMatch == null && !string.IsNullOrEmpty(target.monsterId))
                ownedMatch = data.owned.Find(o => o != null && o.monsterId == target.monsterId);

            // If we don't have it in owned yet, add THIS target as the owned instance
            if (ownedMatch == null)
            {
                data.owned.Add(target);
            }
            else if (!ReferenceEquals(ownedMatch, target))
            {
                // Merge target → ownedMatch (never strip shiny identity)
                CopyAllGameplayFields(from: target, to: ownedMatch);
            }
        }

        // Mirror back to the UI instance if it's a different object
        if (!ReferenceEquals(raw, target))
        {
            CopyAllGameplayFields(from: target, to: raw);
        }

        SaveManager.Save();
        GameEvents.OnTeamChanged?.Invoke();

        return true;
    }

    /// <summary>
    /// Apply stat training (hp/atk/def/spd) via TrainingBonus, then save.
    /// Use this from StatBucketPanelUI.ConfirmSpend or auto-distribute.
    /// </summary>
    public static void ApplyTrainingAndSave(OwnedMonsterData raw, TrainingBonus delta)
    {
        if (raw == null) return;

        var target = FindCanonicalInSave(raw) ?? raw;
        if (target == null) return;

        // Apply to canonical
        MonsterStatApplier.Apply(target, delta);

        // Normalize shiny identity (defensive)
        NormalizeShinyFields(target);

        // Ensure owned entry exists / merged
        var data = SaveManager.Data;
        if (data != null)
        {
            data.owned ??= new List<OwnedMonsterData>();

            OwnedMonsterData ownedMatch = null;

            if (!string.IsNullOrEmpty(target.ownedUID))
                ownedMatch = data.owned.Find(o => o != null && o.ownedUID == target.ownedUID);

            if (ownedMatch == null && !string.IsNullOrEmpty(target.monsterId))
                ownedMatch = data.owned.Find(o => o != null && o.monsterId == target.monsterId);

            if (ownedMatch == null)
            {
                data.owned.Add(target);
            }
            else if (!ReferenceEquals(ownedMatch, target))
            {
                CopyAllGameplayFields(from: target, to: ownedMatch);
            }
        }

        // Mirror back to raw if needed
        if (!ReferenceEquals(raw, target))
        {
            CopyAllGameplayFields(from: target, to: raw);
        }

        SaveManager.Save();
        GameEvents.OnTeamChanged?.Invoke();
    }

    // ---------------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------------

    private static void NormalizeShinyFields(OwnedMonsterData om)
    {
        if (om == null) return;

        // Keep both fields consistent for legacy + new saves
        if (om.shinyTier > 0 && !om.isShiny) om.isShiny = true;
        if (om.isShiny && om.shinyTier <= 0) om.shinyTier = 1;
        if (!om.isShiny && om.shinyTier < 0) om.shinyTier = 0;
    }

    /// <summary>
    /// Copies all gameplay-relevant fields used across systems (team preview, job assignment, codex, etc.).
    /// CRITICAL: includes shiny identity fields so UI pulls the correct icon/name formatting.
    /// </summary>
    private static void CopyAllGameplayFields(OwnedMonsterData from, OwnedMonsterData to)
    {
        if (from == null || to == null) return;

        // Identity
        to.monsterId = from.monsterId;
        to.ownedUID  = from.ownedUID;

        // Core progression
        to.level     = from.level;
        to.currentXP = from.currentXP;
        to.currentHP = from.currentHP;

        // Stat/training progression
        to.unspentStatPoints    = from.unspentStatPoints;
        to.trainingBonus        = from.trainingBonus;
        to.lastBucketId         = from.lastBucketId;
        to.autoApply            = from.autoApply;
        to.autoApplyTargetLevel = from.autoApplyTargetLevel;
        to.trainingLastUnix     = from.trainingLastUnix;
        to.lastLevelClaimDay    = from.lastLevelClaimDay;
        to.pendingLevels        = from.pendingLevels;
        to.isTraining           = from.isTraining;

        // ✅ Shiny identity (MUST persist + mirror)
        to.isShiny   = from.isShiny || from.shinyTier > 0 || to.isShiny;
        to.shinyTier = Mathf.Max(to.shinyTier, from.shinyTier);
        NormalizeShinyFields(to);

        // If your OwnedMonsterData has more fields (KO timers, job state, etc.),
        // add them here rather than letting them silently desync.
        // Example (only if these fields exist in your class):
        // to.lastHPUnix = from.lastHPUnix;
    }
}
