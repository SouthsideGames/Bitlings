using UnityEngine;

public sealed class BattleTempBuffs : MonoBehaviour
{
    public static BattleTempBuffs I { get; private set; }

    private int atkFlat;
    private int hpFlat;
    private int defFlat;
    private int spdFlat;

    private bool typeResistActive;

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
    }

    // ─────────────────────────────────────────────────────────────
    // SETTERS
    // ─────────────────────────────────────────────────────────────
    public void SetPlayerAtkBonus(int flat) => atkFlat = Mathf.Max(0, flat);
    public void SetPlayerHPBonus(int flat) => hpFlat = Mathf.Max(0, flat);
    public void SetPlayerDefenseBonus(int flat) => defFlat = Mathf.Max(0, flat);
    public void SetPlayerSpeedBonus(int flat) => spdFlat = Mathf.Max(0, flat);

    public void SetTypeResistActive(bool on) => typeResistActive = on;

    // ─────────────────────────────────────────────────────────────
    // GETTERS
    // ─────────────────────────────────────────────────────────────
    public int GetPlayerAtkBonus() => atkFlat;
    public int GetPlayerHPBonus() => hpFlat;
    public int GetPlayerDefenseBonus() => defFlat;
    public int GetPlayerSpeedFlatBonus() => spdFlat;

    public bool IsTypeResistActive() => typeResistActive;

    // ─────────────────────────────────────────────────────────────
    // CLEAR
    // ─────────────────────────────────────────────────────────────
    public void ClearPlayerAtkBonus() => atkFlat = 0;
    public void ClearPlayerHPBonus() => hpFlat = 0;
    public void ClearPlayerDefenseBonus() => defFlat = 0;
    public void ClearPlayerSpeedBonus() => spdFlat = 0;

    public void ClearTypeResist() => typeResistActive = false;

    public void ClearAll()
    {
        atkFlat = 0;
        hpFlat = 0;
        defFlat = 0;
        spdFlat = 0;
        typeResistActive = false;
    }
}
