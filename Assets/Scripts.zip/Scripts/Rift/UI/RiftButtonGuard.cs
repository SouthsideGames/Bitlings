using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.EventSystems;

[RequireComponent(typeof(Button))]
public sealed class RiftButtonGuard : MonoBehaviour
    , IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    [Header("Requirements")]
    [SerializeField, Min(1)] private int minRequiredTeamMembers = 1;

    [Header("Feedback")]
    [SerializeField] private RectTransform shakeTarget;
    [SerializeField, Range(0.05f, 0.5f)] private float shakeDuration = 0.2f;
    [SerializeField, Range(1f, 30f)] private float shakeMagnitude = 10f;

    [Header("Hold Action")]
    [SerializeField, Min(0.1f)] private float holdToStopIdleSeconds = 0.5f;

    [Header("Auto-Battle Home Screen UI")]
    [Tooltip("A ring/glow image around the Rift button that pulses while auto is running. Assign in Inspector.")]
    [SerializeField] private GameObject autoPulseRingRoot;

    [Tooltip("Label showing 'Xw - Y⚡' (wins - energy) while auto is running. Assign in Inspector.")]
    [SerializeField] private TMPro.TextMeshProUGUI autoStatusLabel;

    [Tooltip("Overlay panel shown when player taps the Rift button while auto is running. Assign in Inspector.")]
    [SerializeField] private GameObject autoRunningOverlay;

    [Tooltip("How often (seconds) the live counter refreshes while auto is running.")]
    [SerializeField, Min(0.5f)] private float autoCounterRefreshSeconds = 2f;

    private Coroutine _autoCounterCo; // CHANGED: new fields for home-screen auto-battle UX

    private Button _button;
    private Coroutine _shakeRoutine;
    private Coroutine _deferredApply;
    private bool _pressed;
    private bool _holdTriggered;
    private bool _suppressNextClick;
    private float _pressedAt;

    // RiftManager can be created/destroyed across scenes.
    // Hook its OnStateChanged so the button refreshes when battles start/end.
    private RiftManager _hookedRift;

    private void Awake()
    {
        _button = GetComponent<Button>();
        if (!shakeTarget) shakeTarget = GetComponent<RectTransform>();

        // Best-effort early Apply; we also do a deferred Apply to avoid boot-order brittleness.
        Apply();
    }

    private void Start()
    {
        // In case RiftManager comes up after this UI.
        TryHookRiftEvents();

        // Boot-order guard: on some scenes Save/Rift systems may initialize
        // after this button UI. Do one delayed refresh so it never gets stuck.
        if (_deferredApply != null) StopCoroutine(_deferredApply);
        _deferredApply = StartCoroutine(Co_DeferredApply());
    }

    private void OnEnable()
    {
        RiftManager.OnEnergyGained += HandleEnergy;
        GameEvents.EnergyChanged += HandleEnergy;
        GameEvents.OnTeamChanged += HandleTeamChanged;
        GameEvents.OnTeamHealthChanged += HandleTeamChanged;
        GameEvents.AutoBattleModeChanged += HandleAutoModeChanged;
        GameEvents.BattleFinished += HandleBattleFinishedForCounter; // CHANGED: refresh counter on each battle finish

        _button.onClick.AddListener(OnButtonClicked);

        TryHookRiftEvents();

        // Immediate + deferred refresh.
        Apply();

        // CHANGED: sync pulse ring and counter on enable.
        bool autoNow = (RiftManager.I != null && RiftManager.I.IsAutoMode) || IsIdleAutoRunning();
        if (autoPulseRingRoot != null) autoPulseRingRoot.SetActive(autoNow);
        if (autoNow) StartAutoCounter(); else StopAutoCounter();

        if (_deferredApply != null) StopCoroutine(_deferredApply);
        _deferredApply = StartCoroutine(Co_DeferredApply());
    }

    private void OnDisable()
    {
        RiftManager.OnEnergyGained -= HandleEnergy;
        GameEvents.EnergyChanged -= HandleEnergy;
        GameEvents.OnTeamChanged -= HandleTeamChanged;
        GameEvents.OnTeamHealthChanged -= HandleTeamChanged;
        GameEvents.AutoBattleModeChanged -= HandleAutoModeChanged;
        GameEvents.BattleFinished -= HandleBattleFinishedForCounter; // CHANGED
        StopAutoCounter(); // CHANGED

        UnhookRiftEvents();

        if (_deferredApply != null)
        {
            StopCoroutine(_deferredApply);
            _deferredApply = null;
        }

        _button.onClick.RemoveListener(OnButtonClicked);
        if (autoRunningOverlay != null)
            autoRunningOverlay.SetActive(false);
        ResetPressState();
    }

    private void Update()
    {
        // Cheap guard: if RiftManager instance changes across scenes, re-hook.
        // This prevents the button getting stuck disabled after a battle when no
        // energy/team events fire.
        if (_hookedRift != RiftManager.I)
            TryHookRiftEvents();

        if (!_pressed || _holdTriggered) return;

        if (Time.unscaledTime - _pressedAt >= holdToStopIdleSeconds)
        {
            _holdTriggered = true;
            _pressed = false;

            if (TryStopIdleAutoAndShowRewards())
            {
                _suppressNextClick = true;
                Apply();
            }
        }
    }

    private void TryHookRiftEvents()
    {
        var em = RiftManager.I;
        if (em == null)
        {
            UnhookRiftEvents();
            return;
        }

        if (_hookedRift == em) return;

        UnhookRiftEvents();
        _hookedRift = em;
        _hookedRift.OnStateChanged += Apply;
    }

    private void UnhookRiftEvents()
    {
        if (_hookedRift != null)
        {
            _hookedRift.OnStateChanged -= Apply;
            _hookedRift = null;
        }
    }

    private void HandleEnergy(int a, int b) => Apply();
    private void HandleEnergy() => Apply();
    private void HandleTeamChanged() => Apply();
    private void HandleAutoModeChanged(bool isAuto) // CHANGED: drives pulse ring and live counter
    {
        Apply();

        if (autoPulseRingRoot != null)
            autoPulseRingRoot.SetActive(isAuto);

        if (isAuto)
            StartAutoCounter();
        else
            StopAutoCounter();
    }

    private void Apply()
    {
        if (_button == null) return;

        bool idleAutoRunning = IsIdleAutoRunning();
        bool autoRunning = idleAutoRunning || (RiftManager.I != null && RiftManager.I.IsAutoMode);

        if (!autoRunning && autoRunningOverlay != null)
            autoRunningOverlay.SetActive(false);

        bool hasIdleTeam = HasIdleTeamConfigured();
        string reason = null;
        bool ok;

        if (idleAutoRunning)
        {
            ok = false;
            reason = "Idle auto-battle running.";
        }
        else
        {
            bool canStartRift = EligibilityRules.CanStartRift(minRequiredTeamMembers, out reason);
            ok = canStartRift || hasIdleTeam;
            if (ok && hasIdleTeam)
                reason = null;
            else if (!ok && !hasIdleTeam && reason == "No healthy team.")
                reason = "No active or idle team.";
        }

        _button.interactable = ok;

        // Helpful diagnostics when something unexpected disables the button.
        if (!ok && !string.IsNullOrEmpty(reason))
            DevLog.Log($"[RiftButtonGuard] Rift disabled: {reason}", this);
    }

    private IEnumerator Co_DeferredApply()
    {
        yield return new WaitForEndOfFrame();
        Apply();
        _deferredApply = null;
    }

    private void OnButtonClicked()
    {
        if (_suppressNextClick)
        {
            _suppressNextClick = false;
            return;
        }

        // CHANGED: tap while auto is running shows overlay instead of opening battle scene.
        if (IsIdleAutoRunning() || (RiftManager.I != null && RiftManager.I.IsAutoMode))
        {
            if (autoRunningOverlay != null)
                autoRunningOverlay.SetActive(true);
            else
                GameEvents.RaiseToast("Auto-battle is running. Hold the button to stop.");
            return;
        }

        if (!EligibilityRules.CanStartRift(minRequiredTeamMembers, out _))
        {
            StartShake();
            return;
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        _pressed = true;
        _holdTriggered = false;
        _pressedAt = Time.unscaledTime;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        ResetPressState();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        ResetPressState();
    }

    private void ResetPressState()
    {
        _pressed = false;
        _holdTriggered = false;
        _pressedAt = 0f;
    }

    private static bool IsIdleAutoRunning()
    {
        try
        {
            var s = IdleBattleStore.Load();
            return s != null && s.autoBattling;
        }
        catch
        {
            return false;
        }
    }

    private static bool HasIdleTeamConfigured()
    {
        try
        {
            return !IdleLoadoutManager.IsIdleTeamEmpty();
        }
        catch
        {
            return false;
        }
    }

    private bool TryStopIdleAutoAndShowRewards()
    {
        bool autoRunning = IsIdleAutoRunning() || (RiftManager.I != null && RiftManager.I.IsAutoMode);

        if (autoRunning)
        {
            // CHANGED: auto is ON, so toggle it OFF
            bool stoppedAnyAuto = false;

            // Stop foreground rift AUTO loop first.
            var em = RiftManager.I;
            if (em != null && em.IsAutoMode)
            {
                // CHANGED: ToggleAutoMode() exits AutoLoop after the current in-progress battle finishes.
                em.ToggleAutoMode();
                stoppedAnyAuto = true;
            }

            // Stop persisted idle-auto session flag.
            if (IsIdleAutoRunning())
            {
                IdleBattleManager.I?.DisableAuto();
                stoppedAnyAuto = true;

                // Safety net in case IdleBattleManager singleton is not available in this scene.
                try
                {
                    var s = IdleBattleStore.Load();
                    if (s != null && s.autoBattling)
                    {
                        s.autoBattling = false;
                        IdleBattleStore.Save(s);
                    }
                }
                catch { }
            }

            if (stoppedAnyAuto)
            {
                IdleBattleManager.I?.TryOpenSummaryIfNeeded();
            }

            return stoppedAnyAuto;
        }
        else
        {
            // CHANGED: auto is OFF, so toggle it ON (start auto from home screen)
            if (IdleBattleManager.I != null)
            {
                // Verify we have energy before enabling
                int curEnergy = ResourceBank.Get(ResourceType.Energy);
                if (curEnergy <= 0)
                {
                    GameEvents.RaiseToast("Out of energy!");
                    return false;
                }

                IdleBattleManager.I.EnableAuto();
                return true;
            }
            else
            {
                GameEvents.RaiseToast("Idle Battle system not ready.");
                return false;
            }
        }
    }

    private void HandleBattleFinishedForCounter(BattleResult _) => RefreshAutoCounter(); // CHANGED

    private void RefreshAutoCounter() // CHANGED: updates live wins/energy label
    {
        if (autoStatusLabel == null) return;

        bool running = IsIdleAutoRunning() || (RiftManager.I != null && RiftManager.I.IsAutoMode);
        if (!running)
        {
            autoStatusLabel.gameObject.SetActive(false);
            return;
        }

        var s = IdleBattleStore.Load();
        int wins = 0;
        if (s?.log != null)
            foreach (var e in s.log) wins += e.count;

        int energy = 0;
        if (RiftManager.I != null) energy = RiftManager.I.GetEnergyPoints();
        else energy = ResourceBank.Get(ResourceType.Energy);

        autoStatusLabel.text = $"{wins}w - {energy}⚡";
        autoStatusLabel.gameObject.SetActive(true);
    }

    private void StartAutoCounter() // CHANGED: starts periodic refresh
    {
        StopAutoCounter();
        _autoCounterCo = StartCoroutine(Co_AutoCounter());
    }

    private void StopAutoCounter() // CHANGED
    {
        if (_autoCounterCo != null)
        {
            StopCoroutine(_autoCounterCo);
            _autoCounterCo = null;
        }
        if (autoStatusLabel != null)
            autoStatusLabel.gameObject.SetActive(false);
    }

    private IEnumerator Co_AutoCounter() // CHANGED: periodic live-counter refresh
    {
        while (true)
        {
            RefreshAutoCounter();
            yield return new WaitForSeconds(autoCounterRefreshSeconds);
        }
    }

    private void StartShake()
    {
        if (!shakeTarget) return;

        if (_shakeRoutine != null)
            StopCoroutine(_shakeRoutine);

        _shakeRoutine = StartCoroutine(ShakeRoutine());
    }

    private IEnumerator ShakeRoutine()
    {
        Vector3 originalPos = shakeTarget.localPosition;
        float elapsed = 0f;

        while (elapsed < shakeDuration)
        {
            float offsetX = Random.Range(-1f, 1f) * shakeMagnitude;
            float offsetY = Random.Range(-1f, 1f) * shakeMagnitude;

            shakeTarget.localPosition = originalPos + new Vector3(offsetX, offsetY, 0f);

            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        shakeTarget.localPosition = originalPos;
        _shakeRoutine = null;
    }
}
