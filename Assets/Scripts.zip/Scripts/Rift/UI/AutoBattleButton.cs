using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Handles the Rift button on the home screen.
/// - Tap  -> does nothing (PanelButtonUI opens the Rift panel via Button.onClick).
/// - Hold -> toggles idle auto-battle ON/OFF with a 3-second radial fill countdown.
///           Does nothing if Idle Battles are not unlocked.
/// </summary>
public class AutoBattleButton : MonoBehaviour,
    IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    [Header("Hold Settings")]
    [Tooltip("Seconds the player must hold to toggle auto-battle.")]
    public float holdSeconds = 3f;

    [Tooltip("Radial Image (fillAmount 0-1) that fills while holding. Assign in Inspector.")]
    [SerializeField] private Image holdProgressFill;

    [Tooltip("Parent GameObject of the fill image. Hidden immediately if idle battles are locked.")]
    [SerializeField] private GameObject holdFillContainer;

    private bool _pressed;
    private float _pressedAt;
    private bool _firedHold;

    private const float FILL_DEAD_ZONE = 0.15f;

    private void Update()
    {
        if (!_pressed || _firedHold) return;

        if (!IsIdleBattleUnlocked())
        {
            SetFill(0f);
            return;
        }

        float heldFor = Time.unscaledTime - _pressedAt;

        float visibleT = heldFor < FILL_DEAD_ZONE
            ? 0f
            : Mathf.Clamp01((heldFor - FILL_DEAD_ZONE) / (holdSeconds - FILL_DEAD_ZONE));
        SetFill(visibleT);

        if (heldFor >= holdSeconds)
        {
            _firedHold = true;
            _pressed = false;
            SetFill(1f);

            TriggerHaptic();
            ToggleIdleAuto();
            SetFill(0f);
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        _pressed = true;
        _firedHold = false;
        _pressedAt = Time.unscaledTime;
        SetFill(0f);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        ResetPressState();
    }

    public void OnPointerExit(PointerEventData eventData) => ResetPressState();

    private void OnDisable() => ResetPressState();

    private void ToggleIdleAuto()
    {
        if (IsIdleAutoRunning())
        {
            IdleBattleManager.I?.DisableAuto();
        }
        else
        {
            IdleBattleManager.I?.EnableAuto();
        }
    }

    private void SetFill(float amount)
    {
        if (holdProgressFill != null)
            holdProgressFill.fillAmount = amount;
    }

    private void ResetPressState()
    {
        _pressed = false;
        _firedHold = false;
        _pressedAt = 0f;
        SetFill(0f);
    }

    private static bool IsIdleBattleUnlocked()
    {
        try { return FeatureUnlockManager.I != null && FeatureUnlockManager.I.IsUnlocked(FeatureId.IdleBattle_Basic); }
        catch { return false; }
    }

    private static bool IsIdleAutoRunning()
    {
        try { var s = IdleBattleStore.Load(); return s != null && s.autoBattling; }
        catch { return false; }
    }

    private static void TriggerHaptic()
    {
#if UNITY_ANDROID || UNITY_IOS
        Handheld.Vibrate();
#endif
    }
}
