// Assets/Scripts/UI/EncounterButtonGuard.cs
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public sealed class EncounterButtonGuard : MonoBehaviour
{
    [Header("Requirements")]
    [Tooltip("Minimum number of monsters required on the team to start an encounter.")]
    [SerializeField, Min(1)] private int minRequiredTeamMembers = 1;

    [Tooltip("Minimum energy required to start an encounter.")]
    [SerializeField, Min(1)] private int requiredEnergy = 1;

    [Header("Polling")]
    [Tooltip("How often to re-check the requirements (in seconds).")]
    [SerializeField, Range(0.05f, 1f)] private float pollInterval = 0.2f;

    private Button _button;
    private float _timer;

    private void Awake()
    {
        _button = GetComponent<Button>();
        Apply();
    }

    private void OnEnable()
    {
        _timer = pollInterval; // force refresh next frame
    }

    private void Update()
    {
        _timer += Time.unscaledDeltaTime;
        if (_timer >= pollInterval)
        {
            _timer = 0f;
            Apply();
        }
    }

    private void Apply()
    {
        bool hasValidTeam = false;
        bool hasEnoughEnergy = false;

        var data = SaveManager.Data;

        // ─── TEAM CHECK ─────────────────────────────────────────────
        if (data != null && data.team != null)
        {
            int validCount = 0;
            for (int i = 0; i < data.team.Count; i++)
            {
                var entry = data.team[i];
                if (entry != null && !string.IsNullOrEmpty(entry.monsterId))
                {
                    validCount++;
                    if (validCount >= minRequiredTeamMembers)
                    {
                        hasValidTeam = true;
                        break;
                    }
                }
            }
        }

        // ─── ENERGY CHECK ───────────────────────────────────────────
        if (EncounterManager.I != null)
        {
            hasEnoughEnergy = EncounterManager.I.GetEnergyPoints() >= requiredEnergy;
        }
        else
        {
            // fallback if EncounterManager isn’t in the scene yet
            int energy = ResourceBank.Get(ResourceType.Energy);
            hasEnoughEnergy = energy >= requiredEnergy;
        }

        // ─── COMBINE RULES ──────────────────────────────────────────
        bool canPress = hasValidTeam && hasEnoughEnergy;

        if (_button)
            _button.interactable = canPress;

#if UNITY_EDITOR
        // Debug log only for visibility in Play Mode
        if (!canPress)
        {
            if (!hasValidTeam)
                Debug.Log("[EncounterButtonGuard] Disabled — no valid team members.");
            else if (!hasEnoughEnergy)
                Debug.Log("[EncounterButtonGuard] Disabled — not enough energy.");
        }
#endif
    }
}
