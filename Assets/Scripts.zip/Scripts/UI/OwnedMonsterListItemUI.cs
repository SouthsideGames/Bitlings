using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OwnedMonsterListItemUI : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private Image icon;
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI idText;
    [SerializeField] private Button rootButton;

    [Header("KO State (Optional but recommended)")]
    [Tooltip("If assigned, the item will visually dim when KO'd.")]
    [SerializeField] private CanvasGroup canvasGroupWhenKO;
    [Tooltip("Countdown text that shows when a KO'd monster will be usable again.")]
    [SerializeField] private TextMeshProUGUI cooldownText;

    [Header("Detail Panel (Assign Mode)")]
    [SerializeField] private MonsterDetailPanelUI detailPanel;

    // cache
    private OwnedMonsterData _data;
    private MonsterDataSO _def;

    // lightweight refresh
    private float _nextUiRefreshAt;

    void Awake()
    {
        if (detailPanel == null)
            detailPanel = FindAnyObjectByType<MonsterDetailPanelUI>(FindObjectsInactive.Include);

        // make sure countdown is hidden initially
        if (cooldownText) cooldownText.gameObject.SetActive(false);
    }

    void Update()
    {
        // Refresh UI about once per second while KO (no need to spam every frame)
        if (_data == null || string.IsNullOrEmpty(_data.monsterId)) return;
        if (_data.currentHP > 0) return;

        if (Time.unscaledTime >= _nextUiRefreshAt)
        {
            _nextUiRefreshAt = Time.unscaledTime + 1f;
            UpdateKOVisualsAndCountdown();
        }
    }

    public void Setup(OwnedMonsterData data)
    {
        var def = (data != null && !string.IsNullOrEmpty(data.monsterId))
            ? MonsterLibraryLocator.GetById(data.monsterId)
            : null;
        Setup(data, def);
    }

    public void Setup(OwnedMonsterData data, MonsterDataSO def)
    {
        _data = data;
        _def  = def;

        // ─── Icon ───
        if (icon)
        {
            if (def && def.icon)
            {
                icon.enabled = true;
                icon.sprite = def.icon;
            }
            else
            {
                icon.enabled = false;
                icon.sprite = null;
            }
        }

        // ─── Text Fields ───
        if (nameText)
            nameText.text = def
                ? (string.IsNullOrEmpty(def.displayName) ? def.name : def.displayName)
                : "Unknown";

        if (idText)
            idText.text = (data != null && !string.IsNullOrEmpty(data.monsterId))
                ? data.monsterId
                : "—";

        // ─── Button wiring ───
        if (rootButton)
        {
            rootButton.onClick.RemoveAllListeners();
            rootButton.onClick.AddListener(OnClickOpenDetails);
            rootButton.interactable = (data != null && !string.IsNullOrEmpty(data.monsterId) && SafeIsUsable(data));
        }

        // ─── KO visuals + countdown ───
        ApplyKOVisualState();
        UpdateKOVisualsAndCountdown(); // immediate update on setup
        _nextUiRefreshAt = 0f;
    }

    public void SetInteractable(bool on)
    {
        if (rootButton) rootButton.interactable = on && SafeIsUsable(_data);
    }

    private void OnClickOpenDetails()
    {
        if (detailPanel == null)
        {
            Debug.LogWarning("[OwnedMonsterListItemUI] Could not find MonsterDetailPanelUI in scene.");
            return;
        }

        if (_data == null || string.IsNullOrEmpty(_data.monsterId))
            return;

        // Hard stop: KO'd monsters cannot open Assign flow
        if (!SafeIsUsable(_data))
        {
            // Optional: toast message here
            return;
        }

        detailPanel.ShowAssign(_data);
    }

    // ───────────────────────────────────────────────────────────────────────────
    // Helpers
    // ───────────────────────────────────────────────────────────────────────────

    private static bool SafeIsUsable(OwnedMonsterData d)
    {
        if (d == null || string.IsNullOrEmpty(d.monsterId)) return false;
        // HP == 0 → KO → Not usable
        // HP  > 0 → usable
        // HP == -1 (uninitialized) → treat as full/usable (consistent with your team gate)
        return d.currentHP != 0;
    }

    private void ApplyKOVisualState()
    {
        bool isKO = (_data != null && _data.currentHP == 0);

        if (rootButton)
            rootButton.interactable = !isKO && (_data != null && !string.IsNullOrEmpty(_data.monsterId));

        if (canvasGroupWhenKO)
            canvasGroupWhenKO.alpha = isKO ? 0.45f : 1f;

        if (cooldownText)
            cooldownText.gameObject.SetActive(isKO);
    }

    private void UpdateKOVisualsAndCountdown()
    {
        bool isKO = (_data != null && _data.currentHP == 0);
        if (!isKO)
        {
            if (cooldownText) cooldownText.gameObject.SetActive(false);
            if (canvasGroupWhenKO) canvasGroupWhenKO.alpha = 1f;
            if (rootButton) rootButton.interactable = SafeIsUsable(_data);
            return;
        }

        // show countdown
        if (cooldownText)
        {
            var (hasEta, eta) = TryGetETAForNextHP(_data, _def);
            if (hasEta)
            {
                cooldownText.gameObject.SetActive(true);
                cooldownText.text = FormatETA(eta);
            }
            else
            {
                cooldownText.gameObject.SetActive(true);
                cooldownText.text = "Healing…";
            }
        }

        if (canvasGroupWhenKO) canvasGroupWhenKO.alpha = 0.45f;
        if (rootButton) rootButton.interactable = false;
    }

    /// <summary>
    /// Calculates the ETA until the monster gains at least +1 HP via passive regen.
    /// Assumes HealthRegenSystem updates lastHPUnix regularly (it does).
    /// </summary>
    private static (bool ok, TimeSpan eta) TryGetETAForNextHP(OwnedMonsterData d, MonsterDataSO def)
    {
        if (d == null || string.IsNullOrEmpty(d.monsterId)) return (false, TimeSpan.Zero);

        // Determine per-hour rate (monster override > default)
        float perHour = 0f;
        if (def && def.hpRegenPerHour > 0f)
            perHour = def.hpRegenPerHour;
        else
            perHour = HealthRegenSystem.GetDefaultRegenPerHour(); // small helper accessor below

        if (perHour <= 0.0001f) return (false, TimeSpan.Zero);

        // Our regen system awards integer HP using floor(perHour * (deltaSeconds/3600)).
        // The time to next +1 HP is ~ ceil(3600/perHour) since last tick.
        int secondsPerHP = Mathf.CeilToInt(3600f / perHour);

        // If lastHPUnix is 0, assume just started tracking now (show full period).
        var nowUnix = SaveManager.NowUnix();
        long last = d.lastHPUnix > 0 ? d.lastHPUnix : nowUnix;

        long elapsed = Mathf.Max(0, (int)(nowUnix - last));
        int remain = Mathf.Clamp(secondsPerHP - (int)elapsed, 1, secondsPerHP);

        return (true, TimeSpan.FromSeconds(remain));
    }

    private static string FormatETA(TimeSpan span)
    {
        if (span.TotalHours >= 1.0)
            return $"{(int)span.TotalHours}:{span.Minutes:00}:{span.Seconds:00}";
        return $"{span.Minutes:D2}:{span.Seconds:D2}";
    }
}
