using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerDossierPanelUI : MonoBehaviour
{
    [Header("Navigation")]
    [SerializeField] private Button prevButton;
    [SerializeField] private Button nextButton;
    [SerializeField] private TextMeshProUGUI pageLabelText;   // "PAGE 1 / 5"
    [SerializeField] private TextMeshProUGUI dotsText;        // "• ○ ○ ○ ○"

    [Header("Pages (in order)")]
    [SerializeField] private GameObject[] pages; // Page_1_Overview, Page_2_JobSites, etc.

    // ─────────────────────────────────────────────────────────────
    // PAGE 1 – OVERVIEW
    // ─────────────────────────────────────────────────────────────
    [Header("Page 1 - Overview")]
    [SerializeField] private Image avatarImage; // placeholder sprite
    [SerializeField] private TextMeshProUGUI handlerNameText;
    [SerializeField] private TextMeshProUGUI rankText;
    [SerializeField] private TextMeshProUGUI operationIdText;

    [SerializeField] private TextMeshProUGUI totalBitlingsText;
    [SerializeField] private TextMeshProUGUI discoveredSpeciesText;
    [SerializeField] private TextMeshProUGUI avgLevelText;
    [SerializeField] private TextMeshProUGUI shinyCountText;

    [SerializeField] private Image careScoreFillImage;        // the fill bar
    [SerializeField] private TextMeshProUGUI careScoreValueText;
    [SerializeField] private TextMeshProUGUI careScoreNoteText;

    private int _currentPageIndex = 0;

    // Simple container so later we can fill this from real systems.
    [Serializable]
    private class PlayerStatsSnapshot
    {
        public string handlerName;
        public string rankName;
        public string operationId;

        public int totalOwnedBitlings;
        public int discoveredSpecies;
        public float averageLevel;
        public int shinyOwned;

        /// <summary>0–100</summary>
        public float careScorePercent;
        public string careScoreNote;
    }

    private void Awake()
    {
        // Basic safety: ensure pages array is not empty
        if (pages == null || pages.Length == 0)
        {
            Debug.LogWarning("[PlayerDossierPanelUI] No pages assigned.");
        }

        if (prevButton != null)
            prevButton.onClick.AddListener(OnPrevClicked);

        if (nextButton != null)
            nextButton.onClick.AddListener(OnNextClicked);
    }

    private void OnEnable()
    {
        // Always start on Page 0 (Overview) when opening
        _currentPageIndex = 0;
        RefreshPageVisibility();
        RefreshNavigationUI();

        // For now, populate page 1 with placeholder data
        var debugStats = BuildDebugSnapshot(); // TODO: replace with real data later
        PopulatePage1(debugStats);
    }

    private void OnDestroy()
    {
        if (prevButton != null)
            prevButton.onClick.RemoveListener(OnPrevClicked);

        if (nextButton != null)
            nextButton.onClick.RemoveListener(OnNextClicked);
    }

    // ─────────────────────────────────────────────────────────────
    // Navigation
    // ─────────────────────────────────────────────────────────────

    private void OnPrevClicked()
    {
        if (pages == null || pages.Length == 0) return;

        _currentPageIndex--;
        if (_currentPageIndex < 0)
            _currentPageIndex = 0; // Clamp at first page (or wrap if you prefer)

        RefreshPageVisibility();
        RefreshNavigationUI();
    }

    private void OnNextClicked()
    {
        if (pages == null || pages.Length == 0) return;

        _currentPageIndex++;
        if (_currentPageIndex >= pages.Length)
            _currentPageIndex = pages.Length - 1; // Clamp at last page (or wrap)

        RefreshPageVisibility();
        RefreshNavigationUI();
    }

    private void RefreshPageVisibility()
    {
        if (pages == null) return;

        for (int i = 0; i < pages.Length; i++)
        {
            if (pages[i] != null)
            {
                pages[i].SetActive(i == _currentPageIndex);
            }
        }
    }

    private void RefreshNavigationUI()
    {
        int totalPages = (pages != null) ? pages.Length : 0;
        int displayIndex = _currentPageIndex + 1; // 1-based for UI

        if (pageLabelText != null)
        {
            pageLabelText.text = $"PAGE {displayIndex} / {totalPages}";
        }

        if (dotsText != null)
        {
            dotsText.text = BuildDotsString(totalPages, _currentPageIndex);
        }

        // Disable prev on first page, next on last page (optional)
        if (prevButton != null)
            prevButton.interactable = _currentPageIndex > 0;

        if (nextButton != null)
            nextButton.interactable = _currentPageIndex < totalPages - 1;
    }

    private string BuildDotsString(int totalPages, int currentIndex)
    {
        if (totalPages <= 0) return string.Empty;

        // Example: "• ○ ○ ○ ○"
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 0; i < totalPages; i++)
        {
            sb.Append(i == currentIndex ? '•' : '○');
            if (i < totalPages - 1)
                sb.Append(' ');
        }
        return sb.ToString();
    }

    // ─────────────────────────────────────────────────────────────
    // PAGE 1 – POPULATION
    // ─────────────────────────────────────────────────────────────

    private PlayerStatsSnapshot BuildDebugSnapshot()
    {
        // TODO: replace with real values from your SaveManager / Monster collections
        return new PlayerStatsSnapshot
        {
            handlerName = "Handler: KAREEM",      // Placeholder
            rankName = "Rank: Specialist",        // Placeholder
            operationId = "Operation ID: BRN-2049-08-██",

            totalOwnedBitlings = 37,
            discoveredSpecies = 21,
            averageLevel = 12.4f,
            shinyOwned = 3,

            careScorePercent = 78f,
            careScoreNote = "BRN notes: Handler demonstrates stable Bitling care."
        };
    }

    private void PopulatePage1(PlayerStatsSnapshot stats)
    {
        if (stats == null)
        {
            Debug.LogWarning("[PlayerDossierPanelUI] Tried to populate Page 1 with null stats.");
            return;
        }

        // Top identity
        if (handlerNameText != null)
            handlerNameText.text = stats.handlerName;

        if (rankText != null)
            rankText.text = stats.rankName;

        if (operationIdText != null)
            operationIdText.text = stats.operationId;

        // Stats grid
        if (totalBitlingsText != null)
            totalBitlingsText.text = stats.totalOwnedBitlings.ToString();

        if (discoveredSpeciesText != null)
            discoveredSpeciesText.text = stats.discoveredSpecies.ToString();

        if (avgLevelText != null)
            avgLevelText.text = stats.averageLevel.ToString("0.0");

        if (shinyCountText != null)
            shinyCountText.text = stats.shinyOwned.ToString();

        // Care score bar
        float normalized = Mathf.Clamp01(stats.careScorePercent / 100f);

        if (careScoreFillImage != null)
        {
            // Assuming the fill image is using a filled Image type
            if (careScoreFillImage.type == Image.Type.Filled)
            {
                careScoreFillImage.fillAmount = normalized;
            }
            else
            {
                // If it's a simple image, we could also scale X
                careScoreFillImage.rectTransform.anchorMax =
                    new Vector2(normalized, careScoreFillImage.rectTransform.anchorMax.y);
            }
        }

        if (careScoreValueText != null)
            careScoreValueText.text = $"{stats.careScorePercent:0}%";

        if (careScoreNoteText != null)
            careScoreNoteText.text = stats.careScoreNote;

        // Avatar: for now, we just ensure it exists — you can assign a placeholder sprite in the Inspector.
        // Later, plug in your actual player avatar system.
    }
}
