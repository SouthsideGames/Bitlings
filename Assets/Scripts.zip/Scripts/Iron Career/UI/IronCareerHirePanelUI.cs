using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Phase 3.A: IronCareerHirePanelUI
/// Shows the wild monster (from the just-finished battle) and allows Hire/Skip.
/// In Hardcore, skip should be disabled and hire is forced.
/// </summary>
public sealed class IronCareerHirePanelUI : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private IronCareerManager manager;

    [Header("UI")]
    [SerializeField] private Image portrait;
    [SerializeField] private TextMeshProUGUI nameLabel;
    [SerializeField] private TextMeshProUGUI levelLabel;
    [SerializeField] private TextMeshProUGUI titleLabel;

    [Header("Buttons")]
    [SerializeField] private Button hireButton;
    [SerializeField] private Button skipButton;
    [SerializeField] private TextMeshProUGUI skipLabel;

    [Header("Hire Decision Result Prefabs")]
    [SerializeField] private Transform hireResultSpawnPoint;
    [SerializeField] private GameObject hireAgreePrefab;
    [SerializeField] private GameObject hireDenyPrefab;

    private void Awake()
    {
        if (!manager) manager = FindFirstObjectByType<IronCareerManager>();
        if (hireButton) hireButton.onClick.AddListener(OnClickHire);
        if (skipButton) skipButton.onClick.AddListener(OnClickSkip);
    }

    private void OnDestroy()
    {
        if (hireButton) hireButton.onClick.RemoveAllListeners();
        if (skipButton) skipButton.onClick.RemoveAllListeners();
    }

    public void Bind(IronMonster offer, bool skipAllowed)
    {
        ClearHireResultVisuals();

        if (portrait) portrait.sprite = offer != null && offer.def ? offer.def.icon : null;
        if (nameLabel) nameLabel.text = offer != null && offer.def ? offer.def.displayName : "-";
        if (levelLabel) levelLabel.text = offer != null ? $"Lv {Mathf.Max(1, offer.level)}" : string.Empty;
        if (titleLabel) titleLabel.text = (offer != null && offer.lockedTitle) ? offer.lockedTitle.displayName : "";

        if (skipButton)
        {
            skipButton.interactable = skipAllowed;
            skipButton.gameObject.SetActive(skipAllowed);
        }
        if (skipLabel) skipLabel.text = skipAllowed ? "Skip" : "Skip (Hardcore)";
    }

    private void OnClickHire()
    {
        bool success = manager != null && manager.OnHireAccepted();
        SpawnHireResult(success);
    }

    private void OnClickSkip()
    {
        if (manager != null)
            manager.OnHireSkipped();

        SpawnHireResult(false);
    }

    private void SpawnHireResult(bool success)
    {
        if (!hireResultSpawnPoint) return;

        GameObject prefab = success ? hireAgreePrefab : hireDenyPrefab;
        if (!prefab) return;

        ClearHireResultVisuals();
        Instantiate(prefab, hireResultSpawnPoint.position, hireResultSpawnPoint.rotation, hireResultSpawnPoint);
    }

    private void ClearHireResultVisuals()
    {
        if (!hireResultSpawnPoint) return;

        for (int i = hireResultSpawnPoint.childCount - 1; i >= 0; i--)
        {
            var child = hireResultSpawnPoint.GetChild(i);
            if (child) Destroy(child.gameObject);
        }
    }
}
