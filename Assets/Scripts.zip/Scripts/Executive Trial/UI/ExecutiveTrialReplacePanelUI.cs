using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Phase 3.A: ExecutiveTrialReplacePanelUI
/// Choose one party slot to dismiss in order to add the offered hire.
/// </summary>
public sealed class ExecutiveTrialReplacePanelUI : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private ExecutiveTrialManager manager;

    [Tooltip("Optional CanvasGroup for fade + input gating.")]
    [SerializeField] private CanvasGroup panelGroup;

    [Tooltip("Prefab for the incoming recruit card UI.")]
    [SerializeField] private ExecutiveTrialIncomingCardUI incomingCardPrefab;

    [Tooltip("Parent where the incoming card is spawned.")]
    [SerializeField] private Transform incomingCardParent;

    [Tooltip("Parent where party cards are spawned.")]
    [SerializeField] private Transform partyCardParent;

    [Tooltip("Prefab for each party member card.")]
    [SerializeField] private ExecutiveTrialPartyCardUI partyCardPrefab;

    [Header("(New) Buttons")]
    [SerializeField] private Button confirmReplaceButton;
    [SerializeField] private Button cancelButton;

    [Header("(New) Text")]
    [SerializeField] private TextMeshProUGUI warningLabel;

    private readonly List<ExecutiveTrialPartyCardUI> _spawnedPartyCards = new List<ExecutiveTrialPartyCardUI>(3);
    private ExecutiveTrialIncomingCardUI _spawnedIncomingCard;
    private int _selectedIndex = -1;
    private bool _hardcore;

    private void Awake()
    {
        if (!manager) manager = FindFirstObjectByType<ExecutiveTrialManager>();

        if (confirmReplaceButton) confirmReplaceButton.onClick.AddListener(OnConfirmPressed);
        if (cancelButton) cancelButton.onClick.AddListener(OnCancelPressed);
        SetConfirmInteractable(false);
    }

    private void OnDestroy()
    {
        if (confirmReplaceButton) confirmReplaceButton.onClick.RemoveAllListeners();
        if (cancelButton) cancelButton.onClick.RemoveAllListeners();

        for (int i = 0; i < _spawnedPartyCards.Count; i++)
            if (_spawnedPartyCards[i]) Destroy(_spawnedPartyCards[i].gameObject);
        _spawnedPartyCards.Clear();

        if (_spawnedIncomingCard)
        {
            Destroy(_spawnedIncomingCard.gameObject);
            _spawnedIncomingCard = null;
        }
    }

    public void Bind(IReadOnlyList<ExecutiveTrailMonster> party)
    {
        Bind(party, offer: null, hardcoreMode: false);
    }

    /// <summary>
    /// Mobile/vertical bind: show incoming recruit + spawn party cards for selection.
    /// </summary>
    public void Bind(IReadOnlyList<ExecutiveTrailMonster> party, ExecutiveTrailMonster offer, bool hardcoreMode)
    {
        if (!manager) manager = FindFirstObjectByType<ExecutiveTrialManager>();

        // Ensure button listeners are bound even if Awake hasn't fired yet (panel may be inactive).
        if (confirmReplaceButton)
        {
            confirmReplaceButton.onClick.RemoveListener(OnConfirmPressed);
            confirmReplaceButton.onClick.AddListener(OnConfirmPressed);
        }
        if (cancelButton)
        {
            cancelButton.onClick.RemoveListener(OnCancelPressed);
            cancelButton.onClick.AddListener(OnCancelPressed);
        }

        _hardcore = hardcoreMode;
        _selectedIndex = -1;
        SetConfirmInteractable(false);

        if (warningLabel)
            warningLabel.text = "Selected monster will be permanently dismissed. This cannot be undone.";

        // Destroy previous incoming card if any
        if (_spawnedIncomingCard)
        {
            Destroy(_spawnedIncomingCard.gameObject);
            _spawnedIncomingCard = null;
        }

        // Spawn new incoming card
        if (incomingCardPrefab != null && incomingCardParent != null)
        {
            _spawnedIncomingCard = Instantiate(incomingCardPrefab, incomingCardParent);
            _spawnedIncomingCard.Bind(offer);
        }
        else
        {
            Debug.LogWarning("[ExecutiveTrialReplacePanelUI] Missing incomingCardPrefab or incomingCardParent.");
        }

        RebuildPartyCards(party);

        if (cancelButton)
        {
            cancelButton.gameObject.SetActive(!_hardcore);
            cancelButton.interactable = !_hardcore;
        }
    }

    private void RebuildPartyCards(IReadOnlyList<ExecutiveTrailMonster> party)
    {
        for (int i = 0; i < _spawnedPartyCards.Count; i++)
            if (_spawnedPartyCards[i]) Destroy(_spawnedPartyCards[i].gameObject);
        _spawnedPartyCards.Clear();

        if (partyCardPrefab == null || partyCardParent == null)
        {
            Debug.LogWarning("[ExecutiveTrialReplacePanelUI] Missing partyCardPrefab or partyCardParent.");
            return;
        }

        int count = Mathf.Min(3, party != null ? party.Count : 0);
        for (int i = 0; i < count; i++)
        {
            var m = party[i];
            if (m == null || m.def == null) continue;

            var card = Instantiate(partyCardPrefab, partyCardParent);
            card.Bind(m);
            card.SetSelected(false);

            int idx = i;
            card.SetOnClick(() => OnPartyCardPressed(idx));

            _spawnedPartyCards.Add(card);
        }
    }

    private void OnPartyCardPressed(int index)
    {
        _selectedIndex = index;
        for (int i = 0; i < _spawnedPartyCards.Count; i++)
        {
            if (_spawnedPartyCards[i]) _spawnedPartyCards[i].SetSelected(i == _selectedIndex);
        }
        SetConfirmInteractable(_selectedIndex >= 0);
    }

    private void OnConfirmPressed()
    {
        AudioManager.I?.PlayClick();
        if (_selectedIndex < 0) return;
        manager?.OnReplaceChosen(_selectedIndex);
    }

    private void OnCancelPressed()
    {
        AudioManager.I?.PlayClick();
        if (_hardcore) return;
        manager?.OnReplaceCancelled();
    }

    private void SetConfirmInteractable(bool on)
    {
        if (confirmReplaceButton) confirmReplaceButton.interactable = on;
        if (panelGroup)
        {
            panelGroup.blocksRaycasts = true;
            panelGroup.interactable = true;
        }
    }
}