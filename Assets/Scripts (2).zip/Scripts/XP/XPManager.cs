using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Central authority for monster leveling and training bonuses.
/// All level-ups and permanent stat training should go through here so we
/// always modify the canonical OwnedMonsterData stored in SaveManager.Data.
/// </summary>
public static class XPManager
{
    /// <summary>
    /// Returns the canonical OwnedMonsterData from SaveManager.Data
    /// that matches this one by ownedUID (preferred) or monsterId.
    /// If not found, falls back to the source reference.
    /// </summary>
    public static OwnedMonsterData Resolve(OwnedMonsterData source)
    {
        if (source == null) return null;

        var data = SaveManager.Data;
        if (data == null) return source;

        // Prefer matching on ownedUID
        if (!string.IsNullOrEmpty(source.ownedUID))
        {
            var ownedMatch = data.owned?.Find(o => o != null && o.ownedUID == source.ownedUID);
            if (ownedMatch != null) return ownedMatch;

            var teamMatch = data.team?.Find(o => o != null && o.ownedUID == source.ownedUID);
            if (teamMatch != null) return teamMatch;
        }

        // Fallback: match on monsterId
        if (!string.IsNullOrEmpty(source.monsterId))
        {
            var ownedMatch = data.owned?.Find(o => o != null && o.monsterId == source.monsterId);
            if (ownedMatch != null) return ownedMatch;

            var teamMatch = data.team?.Find(o => o != null && o.monsterId == source.monsterId);
            if (teamMatch != null) return teamMatch;
        }

        // Worst case, just use whatever we were passed
        return source;
    }

    /// <summary>
    /// Perform a single manual level-up:
    /// - Spend Growth Cores (using LevelCostCurveSO)
    /// - Increment level
    /// - Add unspent stat points
    /// - Clamp HP to new max
    /// - Save + fire OnTeamChanged
    /// Returns true if level-up succeeded.
    /// </summary>
    public static bool TryManualLevelUp(
        OwnedMonsterData raw,
        int pointsPerLevel,
        LevelCostCurveSO levelCostCurve,
        MonsterLibrarySO monsterLibrary = null)
    {
        if (raw == null || levelCostCurve == null)
            return false;

        var m = Resolve(raw);
        if (m == null || string.IsNullOrEmpty(m.monsterId))
            return false;

        // Cost for NEXT level based on current level
        int need = levelCostCurve.CoresToNextLevel(m.level);

        var rm = ResourceManager.I;
        if (rm == null) return false;

        int have = rm.Get(ResourceType.GrowthCores);
        if (have < need || need <= 0)
            return false;

        // Spend cores
        rm.Add(ResourceType.GrowthCores, -need);

        // Level up + stat points
        m.level = Mathf.Max(1, m.level + 1);
        m.unspentStatPoints += Mathf.Max(0, pointsPerLevel);

        // Clamp HP to new max
        MonsterDataSO def = null;
        if (monsterLibrary != null)
        {
            def = monsterLibrary.GetById(m.monsterId);
        }
        else
        {
            // Your existing global access
            def = MonsterLibraryLocator.GetById(m.monsterId);
        }

        if (def)
        {
            int newMaxHP = Mathf.RoundToInt(BattleCalc.CalcHP(def, m.level));
            if (m.currentHP > newMaxHP)
                m.currentHP = newMaxHP;
        }

        SaveManager.Save();
        GameEvents.OnTeamChanged?.Invoke();

        return true;
    }

    /// <summary>
    /// Apply stat training (hp/atk/def/spd) via TrainingBonus, then save.
    /// Use this from StatBucketPanelUI.ConfirmSpend or auto-distribute.
    /// </summary>
    public static void ApplyTrainingAndSave(OwnedMonsterData raw, TrainingBonus delta)
    {
        if (raw == null) return;

        var m = Resolve(raw);
        if (m == null) return;

        MonsterStatApplier.Apply(m, delta);
        SaveManager.Save();
        SaveDebugTools.ExportAuditJson(true);
        GameEvents.OnTeamChanged?.Invoke();
    }
}
