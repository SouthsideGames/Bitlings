using System;
using System.Collections.Generic;
using UnityEngine;

public static class DiagnosticsTrace
{
    public struct EncounterStart
    {
        public long unix;
        public string monsterId;
        public string monsterName;
        public int level;
        public bool isBoss;
        public bool isShiny;
        public string seedInfo;
    }

    public struct RollRecord
    {
        public long unix;
        public string kind;
        public string monsterId;
        public float chance;
        public float roll;
        public bool success;
        public string extra;
    }

    private static EncounterStart _lastEncounter;
    private static RollRecord _lastShinyRoll;
    private static RollRecord _lastCaptureRoll;
    private static RollRecord _lastHireRoll;

    private static readonly List<string> _lines = new List<string>(64);
    private const int MAX_LINES = 50;

    public static EncounterStart LastEncounter => _lastEncounter;
    public static RollRecord LastShinyRoll => _lastShinyRoll;
    public static RollRecord LastCaptureRoll => _lastCaptureRoll;
    public static RollRecord LastHireRoll => _lastHireRoll;
    public static IReadOnlyList<string> Lines => _lines;

    public static void RecordEncounterStart(MonsterDataSO def, int level, bool isBoss, bool isShiny, string seedInfo = null)
    {
        _lastEncounter = new EncounterStart
        {
            unix = SafeNowUnix(),
            monsterId = def ? def.id : null,
            monsterName = def ? def.displayName : null,
            level = Mathf.Max(1, level),
            isBoss = isBoss,
            isShiny = isShiny,
            seedInfo = seedInfo
        };

        PushLine($"[ENCOUNTER] {(_lastEncounter.monsterName ?? _lastEncounter.monsterId ?? "?")} L{_lastEncounter.level} boss={_lastEncounter.isBoss} shiny={_lastEncounter.isShiny} seed={seedInfo}");
    }

    public static void RecordShinyRoll(MonsterDataSO def, float chance01, float roll01, bool success, string extra = null)
    {
        _lastShinyRoll = new RollRecord
        {
            unix = SafeNowUnix(),
            kind = "SHINY",
            monsterId = def ? def.id : null,
            chance = Mathf.Clamp01(chance01),
            roll = Mathf.Clamp01(roll01),
            success = success,
            extra = extra
        };

        PushLine($"[ROLL:SHINY] {(_lastShinyRoll.monsterId ?? "?")} roll={_lastShinyRoll.roll:0.000} <= chance={_lastShinyRoll.chance:0.000} => {(_lastShinyRoll.success ? "YES" : "NO")} {extra}".Trim());
    }

    public static void RecordCatchRoll(string context, MonsterDataSO def, float chance01, float roll01, bool success, string extra = null)
    {
        context = string.IsNullOrWhiteSpace(context) ? "CATCH" : context.Trim().ToUpperInvariant();

        var rec = new RollRecord
        {
            unix = SafeNowUnix(),
            kind = context,
            monsterId = def ? def.id : null,
            chance = Mathf.Clamp01(chance01),
            roll = Mathf.Clamp01(roll01),
            success = success,
            extra = extra
        };

        if (context == "HIRE") _lastHireRoll = rec;
        else _lastCaptureRoll = rec;

        PushLine($"[ROLL:{context}] {(rec.monsterId ?? "?")} roll={rec.roll:0.000} <= chance={rec.chance:0.000} => {(rec.success ? "SUCCESS" : "FAIL")} {extra}".Trim());
    }

    private static void PushLine(string line)
    {
        if (string.IsNullOrEmpty(line)) return;

        if (_lines.Count >= MAX_LINES)
            _lines.RemoveAt(0);

        _lines.Add(line);
    }

    private static long SafeNowUnix()
    {
        try { return SaveManager.NowUnix(); }
        catch { return DateTimeOffset.UtcNow.ToUnixTimeSeconds(); }
    }
}
