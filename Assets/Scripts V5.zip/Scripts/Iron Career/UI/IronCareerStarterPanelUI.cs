using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Phase 3.A: IronCareerStarterPanelUI
/// - Mode select (Standard/Hardcore)
/// - Starter roulette (random starter party)
///
/// This panel is runtime-only; it never touches SaveManager.
/// </summary>
public sealed class IronCareerStarterPanelUI : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private IronCareerManager manager;

    [Header("Mode")]
    [SerializeField] private Toggle standardToggle;
    [SerializeField] private Toggle hardcoreToggle;

    [Header("Starter Roulette")]
    [SerializeField] private Button rerollButton;
    [SerializeField] private Button startButton;

    [SerializeField] private List<Image> starterIcons = new List<Image>(3);
    [SerializeField] private List<TextMeshProUGUI> starterNames = new List<TextMeshProUGUI>(3);

    private List<MonsterDataSO> _current = new List<MonsterDataSO>(3);

    private void Awake()
    {
        if (!manager) manager = FindFirstObjectByType<IronCareerManager>();

        if (rerollButton) rerollButton.onClick.AddListener(Reroll);
        if (startButton) startButton.onClick.AddListener(OnStartClicked);

        // default
        if (standardToggle && hardcoreToggle)
        {
            standardToggle.isOn = true;
            hardcoreToggle.isOn = false;
        }
    }

    private void OnEnable()
    {
        // Always show a fresh roulette when opening.
        Reroll();
    }

    private void OnDestroy()
    {
        if (rerollButton) rerollButton.onClick.RemoveListener(Reroll);
        if (startButton) startButton.onClick.RemoveListener(OnStartClicked);
    }

    public void Reroll()
    {
        _current = manager != null ? manager.RollStarterPartyRoulette() : new List<MonsterDataSO>();
        ApplyPreview(_current);
    }

    private void ApplyPreview(List<MonsterDataSO> defs)
    {
        for (int i = 0; i < 3; i++)
        {
            var def = (defs != null && i < defs.Count) ? defs[i] : null;
            if (starterIcons != null && i < starterIcons.Count && starterIcons[i])
                starterIcons[i].sprite = def ? def.icon : null;

            if (starterNames != null && i < starterNames.Count && starterNames[i])
                starterNames[i].text = def ? def.displayName : "-";
        }
    }

    private void OnStartClicked()
    {
        if (!manager) return;

        var mode = IronCareerRunState.IronCareerMode.Standard;
        if (hardcoreToggle && hardcoreToggle.isOn)
            mode = IronCareerRunState.IronCareerMode.Hardcore;

        manager.StartNewRunFromUI(mode, _current);
    }
}
