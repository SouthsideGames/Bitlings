using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public enum PanelId
{
    None = 0,
    Intro = 1,
    Encounter = 2,
    Gym = 3,
    Home = 4,
    Resources = 5,
    Upgrades = 6,
    Codex = 7,
    JobAssign = 8,
    Harbor = 9,
    CryoLab = 10,
    Sanctum = 11,
    WyrmDen = 12,
    ShadowMarket = 13,
    Settings = 14,
    RewardPopup = 15,
    MonsterDetail = 16,
    Evolution = 17,
    TitleDetail = 18,
    StarterPicker = 19,
    Forge = 20,
    Info = 22,
    Log = 23,
    PostBattleSummary = 24,
    Achievement = 25,
    CheatCodes = 26,
    Expedition = 27,
    PackDetails = 28,
    Recycle = 29,
    Story = 30,
    PlayerDossier = 31,
    ImagePreview = 32,
    IdleBattleRewards = 33,

    // ─────────────────────────────────────────────────────────────
    // Iron Career (sealed mode) MAIN container panel
    // This maps to: Canvas/Panel_IronCareerEncounter
    // ─────────────────────────────────────────────────────────────
    IronCareerEncounter = 34,

    // ─────────────────────────────────────────────────────────────
    // Iron Career (sealed mode) overlays (children inside IronCareerEncounter)
    // ─────────────────────────────────────────────────────────────
    IronCareerStarter = 35,
    IronCareerHire = 36,
    IronCareerReplace = 37,
    IronCareerPost = 38,
    IronCareerForcedEvolve = 39,
    IronCareerRest = 40,
    IronCareerGameOver = 41,
    IronCareerRules = 42,
}

[Serializable]
public class PanelEntry
{
    public PanelId id;
    public GameObject root;

    [Tooltip("If false, UIManager will NOT add/use a CanvasGroup or fade this panel.")]
    public bool useFade = true;

    [Tooltip("Optional slide animation even when fade is disabled.")]
    public bool useSlide = true;
}

public class UIManager : MonoBehaviour
{
    public static UIManager I { get; private set; }

    [Header("Panels")]
    [SerializeField] private List<PanelEntry> panels = new();

    [Header("Navigation")]
    [Tooltip("If enabled, opening a MAIN panel will automatically close any other MAIN panels (ex: Home won't stay open under Codex). Overlays/popups are not affected.")]
    [SerializeField] private bool singleMainPanelMode = true;

    [Tooltip("Panels treated as overlays/popups. They are allowed to stack and will NOT be auto-closed when opening a main panel.")]
    [SerializeField] private List<PanelId> overlayPanels = new()
    {
        PanelId.RewardPopup,
        PanelId.MonsterDetail,
        PanelId.Evolution,
        PanelId.TitleDetail,
        PanelId.Info,
        PanelId.Log,
        PanelId.PostBattleSummary,
        PanelId.Achievement,
        PanelId.CheatCodes,
        PanelId.PackDetails,
        PanelId.ImagePreview,
        PanelId.IdleBattleRewards,

        // Iron overlays/popups
        PanelId.IronCareerStarter,
        PanelId.IronCareerHire,
        PanelId.IronCareerReplace,
        PanelId.IronCareerPost,
        PanelId.IronCareerForcedEvolve,
        PanelId.IronCareerRest,
        PanelId.IronCareerGameOver,
        PanelId.IronCareerRules,
    };

    [Header("Animation")]
    [SerializeField] private float openFadeDuration = 0.18f;
    [SerializeField] private float closeFadeDuration = 0.16f;
    [SerializeField] private float slideOffsetY = -30f;

    public event Action<PanelId, bool> OnPanelChanged;

    private readonly Dictionary<PanelId, PanelEntry> _map = new();
    private readonly HashSet<PanelId> _open = new();

    private Coroutine _idleRewardCo;

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;

        _map.Clear();
        foreach (var p in panels)
        {
            if (p == null || p.root == null) continue;

            if (!_map.ContainsKey(p.id))
                _map.Add(p.id, p);

            SetImmediate(p.id, p.root.activeSelf, fireEvent: false);

            if (p.root.activeSelf && p.useFade)
            {
                var cg = EnsureCanvasGroup(p.root);
                cg.alpha = 1f;
                cg.interactable = true;
                cg.blocksRaycasts = true;
            }
        }
    }

    void Start()
    {
        CloseAll();
        Show(PanelId.Intro);
    }

    public void Show(PanelId id) => SetActive(id, true);
    public void Toggle(PanelId id) => SetActive(id, !_open.Contains(id));
    public bool IsOpen(PanelId id) => _open.Contains(id);

    public bool Hide(PanelId id)
    {
        if (!_map.TryGetValue(id, out var p) || p.root == null) return false;
        SetActive(id, false);
        return true;
    }

    public void CloseAll()
    {
        var list = new List<PanelId>(_open);
        foreach (var id in list)
            SetImmediate(id, false, fireEvent: false);

        _open.Clear();
    }

    public void CloseAllExcept(PanelId keep)
    {
        var list = new List<PanelId>(_open);
        foreach (var id in list)
            if (id != keep) SetActive(id, false);
    }

    public GameObject GetRoot(PanelId id) => _map.TryGetValue(id, out var e) ? e.root : null;

    void TryOpenIdleBattleRewardsNextFrame()
    {
        if (_idleRewardCo != null) StopCoroutine(_idleRewardCo);
        _idleRewardCo = StartCoroutine(Co_TryOpenIdleBattleRewardsNextFrame());
    }

    IEnumerator Co_TryOpenIdleBattleRewardsNextFrame()
    {
        yield return null;
        IdleBattleManager.I?.TryOpenSummaryIfNeeded();
    }

    private void SetImmediate(PanelId id, bool on, bool fireEvent)
    {
        if (!_map.TryGetValue(id, out var p) || p.root == null) return;

        CancelTweens(p.root);

        if (on)
        {
            p.root.SetActive(true);

            if (p.useFade)
            {
                var cg = EnsureCanvasGroup(p.root);
                cg.alpha = 1f;
                cg.interactable = true;
                cg.blocksRaycasts = true;
            }

            var rt = p.root.GetComponent<RectTransform>();
            if (rt && p.useSlide)
            {
                var pos = rt.anchoredPosition;
                rt.anchoredPosition = new Vector2(pos.x, 0f);
            }

            _open.Add(id);
        }
        else
        {
            if (p.useFade)
            {
                var cg = p.root.GetComponent<CanvasGroup>();
                if (cg != null)
                {
                    cg.interactable = false;
                    cg.blocksRaycasts = false;
                    cg.alpha = 0f;
                }
            }

            p.root.SetActive(false);
            _open.Remove(id);
        }

        if (fireEvent) OnPanelChanged?.Invoke(id, on);
    }

    private void SetActive(PanelId id, bool on, bool fireEvent = true)
    {
        if (!_map.TryGetValue(id, out var p) || p.root == null)
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            Debug.LogWarning($"[UIManager] No panel root for {id}");
#endif
            return;
        }

        if (on)
        {
            if (singleMainPanelMode && !IsOverlayPanel(id))
            {
                CloseAllMainPanelsExcept(id);
            }

            if (_open.Add(id))
            {
                AnimateOpen(p);
                if (fireEvent) OnPanelChanged?.Invoke(id, true);

                if (id == PanelId.Home)
                    TryOpenIdleBattleRewardsNextFrame();
            }
        }
        else
        {
            if (_open.Remove(id))
            {
                AnimateClose(p, () =>
                {
                    p.root.SetActive(false);
                    if (fireEvent) OnPanelChanged?.Invoke(id, false);
                });
            }
        }
    }

    private bool IsOverlayPanel(PanelId id)
    {
        return overlayPanels != null && overlayPanels.Contains(id);
    }

    private void CloseAllMainPanelsExcept(PanelId keepMain)
    {
        var list = new List<PanelId>(_open);
        foreach (var id in list)
        {
            if (id == keepMain) continue;
            if (IsOverlayPanel(id)) continue;
            SetActive(id, false);
        }
    }

    private void AnimateOpen(PanelEntry p)
    {
        var root = p.root;
        CancelTweens(root);

        root.SetActive(true);

        RectTransform rt = root.GetComponent<RectTransform>();

        if (p.useSlide && rt)
        {
            var pos = rt.anchoredPosition;
            rt.anchoredPosition = new Vector2(pos.x, slideOffsetY);
            LeanTween.moveY(rt, 0f, openFadeDuration).setEaseOutCubic();
        }

        if (p.useFade)
        {
            CanvasGroup cg = EnsureCanvasGroup(root);
            cg.interactable = true;
            cg.blocksRaycasts = true;

            cg.alpha = 0f;
            LeanTween.alphaCanvas(cg, 1f, openFadeDuration).setEaseOutCubic();
        }
    }

    private void AnimateClose(PanelEntry p, Action onComplete)
    {
        var root = p.root;
        CancelTweens(root);

        RectTransform rt = root.GetComponent<RectTransform>();

        float dur = closeFadeDuration;
        bool anyTween = false;

        if (p.useFade)
        {
            anyTween = true;

            CanvasGroup cg = EnsureCanvasGroup(root);
            cg.interactable = false;
            cg.blocksRaycasts = false;

            LeanTween.alphaCanvas(cg, 0f, dur).setEaseInCubic();
        }

        if (p.useSlide && rt)
        {
            anyTween = true;
            LeanTween.moveY(rt, slideOffsetY, dur).setEaseInCubic();
        }

        if (anyTween)
            LeanTween.delayedCall(root, dur, () => onComplete?.Invoke());
        else
            onComplete?.Invoke();
    }

    private static CanvasGroup EnsureCanvasGroup(GameObject root)
    {
        var cg = root.GetComponent<CanvasGroup>();
        if (cg == null) cg = root.AddComponent<CanvasGroup>();
        return cg;
    }

    private static void CancelTweens(GameObject root)
    {
        if (!root) return;
        LeanTween.cancel(root);

        var rt = root.GetComponent<RectTransform>();
        if (rt) LeanTween.cancel(rt.gameObject);
    }
}